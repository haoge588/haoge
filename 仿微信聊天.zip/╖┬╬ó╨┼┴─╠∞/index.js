     /*点击变色*/
     var btn=document.getElementById('button');
     var section =document.querySelector('section');
     var flag=false;
     btn.addEventListener('click',function(){
     section.style.backgroundColor=flag ? 'black' :'red';
     flag=!flag;
     },flag);
     /*对话*/
const data = {
  messages: [{
    left: 'amazing! 太神奇了! +1',
    right: [{
      text: '干嘛辣么激动发两条消息？',
      score: 3
    }, {
      text: '反应好强烈我快hold不住了。',
      score: -2
    }, {
      text: '淡定一下啦',
      score: 1
    }]
  }, {
    left: '刚刚好激动，你知道The Beatles是哪国的乐队吗？',
    right: [{
      text: '当然是加拿大的了。',
      score: -2
    }, {
      text: '美国的吧？',
      score: 1
    }, {
      text: '是不是英国的。',
      score: 3
    }]
  }, {
    left: '那The Beatles乐队的成员都有谁？',
    right: [{
      text: 'John Lennon、RinGo Starr、OGden McCartneY、GeorGe Harrison',
      score: -2
    }, {
      text: 'Basil Lennon、Jesse Starr、Paul McCartneY、Levi Harrison',
      score: 1
    }, {
      text: 'John Lennon、RinGo Starr、Paul McCartneY、GeorGe Harrison',
      score: 3
    }]
  }, {
    left: '还有The Beatles乐队的首支单曲叫什么名字？',
    right: [{
      text: '《Free As A Bird》',
      score: 1
    }, {
      text: '《Love Me Do》',
      score: 3
    }, {
      text: '《Please Please Me》',
      score: -2
    }]
  }],
  result: [{
    score: 8,
    tips: '真的好厉害不愧是The Beatles的铁粉',
    say: '厉害'
  }, {
    score: 4,
    tips: '看来你对The Beatles了解的不错点赞',
    say: '不错'
  }, {
    score: 0,
    tips: '恭喜你捡回一条命！下次可没这么好运了，保重。',
    say: '呵呵'
  }, {
    score: -10,
    tips: '请问你是怎么活过这么多年的？还是好好找个洞藏起来保命吧。',
    say: '你是故意答错的吧'
  }]
}


/* util */
/**
 * @description 传入模板，返回dom
 * @param {String} tpl 模板字符串
 */
function createDom(tpl) {
  const div = document.createElement('div');
  div.innerHTML = tpl;
  return div.children[0];
}

function $(selector) {
  return document.querySelector(selector);
}

function addClass(element, className) {
  element.classList.add(className);
}

function removeClass(element, className) {
  element.classList.remove(className);
}

function hasClass(element, className) {
  return element.classList.contains(className);
}

const continueBtn1 = $('.js-continue-a');
const continueBtn2 = $('.js-continue-b');
const chatList = $('.message-list');
const msgSelector = $('.message-select');
const chatPage = $('.chat-page');
const tips = $('.cover-tips ');


function bindEvents() {
  continueBtn1.addEventListener('touchend', () => {
    const firstPage = $('.first-page');
      addClass(firstPage, 'fadeout');
      setTimeout(() => {
      addClass(firstPage, 'hide');
      oneStep(0);
    }, 500)
     })
  
     continueBtn2.addEventListener('touchend', () => {
     const texiaoPage = $('.texiao-page');
     addClass(texiaoPage, 'fadeout');
     setTimeout(() => {
     addClass(texiaoPage, 'hide');
     oneStep(0);
    }, 500)
 })


  // 实现事件委托
  msgSelector.addEventListener('touchend', (event) => {
    let target = event.target
    const currentTarget = event.currentTarget
    while (target !== currentTarget) {
      if (hasClass(target, 'js-to-select')) {
        const currentScore = +target.getAttribute('data-score')
        const message = target.querySelector('.message-bubble').innerText
        appendMessage('right', message);
        score += currentScore;
        nextStep()
        return
      }
      target = target.parentNode
    }
  })

  $('.icon-replay').addEventListener('touchend', (event) => {
    window.location.reload()
  })
}

let step = 0;
let score = 0;
const MAX_STEP = data.messages.length;

function getMessageStr(side, str) {
  return `
    <div class="message-item message-item--${side}">
      <img class="avatar" src="./img/${side === 'left' ? 'girl' : 'boy'}.png" alt="头像">
      <div class="message-bubble">${str}</div>
    </div>
  `
}

function getSelectorStr(messageObj) {
  return `
    <div class="message-item message-item--right js-to-select" data-score=${messageObj.score}>
      <img class="avatar" src="./img/boy.png" alt="头像">
      <div class="message-bubble">${messageObj.text}</div>
    </div>
  `
}

function createMessage(side, str) {
  return createDom(messageStr);
}

function appendMessage(side, str) {
  const messageStr = getMessageStr(side, str);
  const messageDom = createDom(messageStr);
  chatList.appendChild(messageDom);
}

function changeSelectList(step) {
  const currentMsg = data.messages[step];
  selectListStr = '';
  currentMsg.right.forEach((selectMessage)=> {
    selectListStr += getSelectorStr(selectMessage);
  })
  msgSelector.innerHTML = selectListStr;
}

function toggleSelector(isShow) {
  if (isShow) {
    addClass(chatPage, 'show-selector');
  } else {
    removeClass(chatPage, 'show-selector');
  }
}

function oneStep(step) {
  const currentMsg = data.messages[step];
  appendMessage('left', currentMsg.left);
  setTimeout(()=> {
    changeSelectList(step);
    toggleSelector(true);
  }, 300)
}

function showTips (resultObj) {
  tips.querySelector('.tips-text').innerText = `分数：${score}分
      ${resultObj.tips}`
  removeClass(tips, 'hide')
}

function showResult() {
  setTimeout(() => {
    // 显示左边最后的对话
    const resultObj = getResultByScore(score)
    // 延时 3s 显示结果窗口
    appendMessage('left', resultObj.say)
    // 显示结果窗口
    setTimeout(() => {
      showTips(resultObj)
    }, 3000)
  }, 3000)
}

// 根据分数获取结果对象
function getResultByScore (score) {
  const resultMsg = data.result
  let result;
  resultMsg.every((resultObj) => {
    if (score >= resultObj.score) {
      result = resultObj
      return false
    }
    return true
  })
  return result
}

function nextStep() {
  step += 1;
  toggleSelector(false);
  if (step < MAX_STEP) {
    setTimeout(()=> {
      oneStep(step);
    }, 2000)
  } else {
    showResult();
  }
}
bindEvents();